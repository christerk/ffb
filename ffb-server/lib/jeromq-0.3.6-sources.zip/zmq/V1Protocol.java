package zmq;

class V1Protocol
{
    private V1Protocol()
    {
    }

    public static final int VERSION = 1;
    public static final int MORE_FLAG = 1;
    public static final int LARGE_FLAG = 2;
}
